public interface IOperation {
    public int Operation(int num1, int num2);
}
