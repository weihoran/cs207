package UseCases;

import Entity.*;
import java.util.ArrayList;

public class UserManager {
    public static ArrayList<User> userlist;

    public UserManager(ArrayList<User> userList){
        userlist = userList;
    } //denpendcy injection

    public String getUser(String username){
        for(User u : userlist){
            if(u.getUsername().equals(username))
                return u.toString();
        }
        return "no such user";
    }

    public boolean verifyUser(String id, String password){
        for(User u : userlist){
            if(u.getUsername().equals(id) && u.getPassword().equals(password))
                return true;
        }
        return false;
    }

    public void createRegularUser(String username, String pw){
        User user = new RegularUser(username, pw);
        userlist.add(user);
    }

}
