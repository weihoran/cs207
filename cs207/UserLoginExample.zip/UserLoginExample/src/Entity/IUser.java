package Entity;

public interface IUser {



     String getUsername();
     void setUsername(String userid);
     String getPassword();
     void setPassword(String password);

}
